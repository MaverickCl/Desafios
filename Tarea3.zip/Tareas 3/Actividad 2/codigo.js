var btnSum=document.getElementById("btnSuma")
var btnRes=document.getElementById("btnResta")
var btnDiv=document.getElementById("btnDiv")
var btnMult=document.getElementById("btnMult")

var resultado=document.getElementById("resultado");

var n1=document.getElementById("numero1");
var n2=document.getElementById("numero2");

btnSum.addEventListener("click",function(){
var input1=n1.value;
var input2=n2.value;

resultado.innerHTML=suma(input1,input2)
});
btnRes.addEventListener("click",function(){
    var input1=n1.value;
    var input2=n2.value;
    
    resultado.innerHTML=resta(input1,input2)
    });
btnMult.addEventListener("click",function(){
        var input1=n1.value;
        var input2=n2.value;
        
        resultado.innerHTML=multiplicacion(input1,input2)
        });
btnDiv.addEventListener("click",function(){
            var input1=n1.value;
            var input2=n2.value;
            
            resultado.innerHTML=division(input1,input2)
            });
function suma(numUno,numDos){
    return parseInt(numUno)+parseInt(numDos)
}
function resta(numUno,numDos){
    return parseInt(numUno)-parseInt(numDos)
}
function division(numUno,numDos){
    return parseInt(numUno)/parseInt(numDos)
}
function multiplicacion(numUno,numDos){
    return parseInt(numUno)*parseInt(numDos)
}