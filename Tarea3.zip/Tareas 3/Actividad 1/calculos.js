var btn = document.getElementById("btn");
var resultado = document.getElementById("resultado")
var inputUno = document.getElementById("min");
var inputDos = document.getElementById("max");

btn.addEventListener("click",function(){
    var n1 = inputUno.value;
    var n2 = inputDos.value;
    resultado.innerHTML = generarRandom(n1,n2);
    });



function generarRandom(numeroMin,numeroMax){
    var numMin = parseInt(numeroMin);
    var numMax = parseInt(numeroMax);
    return Math.floor(Math.random() * (numMax - numMin)) + numMin;
}