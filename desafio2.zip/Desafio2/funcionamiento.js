const btnNumbers = document.getElementsByName('btnNumbers');
const btnNumbers2 = document.getElementsByName('btnNumbers');
console.log(btnNumbers);
const btnFuntion = document.getElementsByName('btnFuntion');
console.log(btnFuntion);
const delete1 = document.getElementsByName('delete1')[0];
console.log(delete1);
const deleteAll = document.getElementsByName('deleteAll')[0];
console.log(deleteAll);
const equal = document.getElementsByName('equal')[0];
var resultado='';
var number='';
var numberTwo='';
var inputSign='';
var inputOne= document.getElementById('inputOne');
var inputFuncion= document.getElementById('inputFuncion');
var inputTwo= document.getElementById('inputTwo');
var result= document.getElementById('result');


  btnNumbers.forEach(function(boton){
    boton.addEventListener('click',function(){
        addImput(boton.innerText);
    });
  });


  btnFuntion.forEach(function(boton){
    boton.addEventListener('click',function(){
      assignOperation(boton.innerText);
    });
  });

deleteAll.addEventListener('click',function(){
reseteo();
});


equal.addEventListener('click',function(){
switch(inputSign){
  case '+':
    sumar(number,numberTwo)
    break;
  case '-':
    restar(number,numberTwo)
    break;
  case 'x':
    multiplicar(number,numberTwo)
    break;
  case '/':
    dividir(number,numberTwo)
    break;
  case '+/-':
    signChange(numberTwo)
    break;
}

});

delete1.addEventListener('click',function(){
numberTwo=numberTwo.slice(0,-1)
  atualizarDisplay();
})


  function assignOperation(sign){
    inputSign= sign;
    if(sign!='+/-'){
    number=numberTwo;
    numberTwo='';
    }
    atualizarDisplay();
  }
function addImput(num){
    numberTwo=numberTwo.toString() + num.toString();
  atualizarDisplay();

  
}
function atualizarDisplay(){
  inputOne.innerHTML=number;
  inputFuncion.innerHTML= inputSign;
  inputTwo.innerHTML= numberTwo;
  result.innerHTML=resultado;
};
function sumar(n1,n2){

  resultado=parseFloat(n1)+parseFloat(n2)
  atualizarDisplay()
};

function restar(n1,n2){
  resultado=parseFloat(n1)-parseFloat(n2)
  atualizarDisplay()
    };
    
function dividir(n1,n2){
  resultado=parseFloat(n1)/parseFloat(n2)
  atualizarDisplay()
    };

function multiplicar(n1,n2){
    resultado=parseFloat(n1)*parseFloat(n2)
    atualizarDisplay()
    };
function signChange(n){
  resultado=((parseFloat(n))*(-1));
  atualizarDisplay()
}
function reseteo(n1,n2){
number='';
numberTwo='';
inputSign='';
resultado='';
atualizarDisplay();
};

